# Part 13 — Delivery Plan, Team Workstreams, Milestones and Definition of Done

The owner has stated that a large team can work in parallel. Structure the project accordingly, but maintain shared architecture and integration gates.

## 13.1 Workstreams

### Squad A — Platform/SaaS
- auth;
- tenancy;
- projects;
- billing;
- reports;
- usage;
- admin.

### Squad B — Output
- OPD Guard;
- FormDoctor;
- Custom Field Flow;
- Extension Impact.

### Squad C — Migration
- SPRO2Cloud;
- ECC2Cloud;
- Gap Radar;
- Clean Core Guard.

### Squad D — Integration/Release
- Change Pointer;
- API Change;
- Software Collection;
- Transport dependencies.

### Squad E — Operations
- Safe Decommission;
- Fiori 403;
- Workflow;
- IAM;
- Account Determination;
- Refresh.

### Squad F — MFS
- parsing;
- state model;
- causal replay;
- reproduction;
- test generation.

### Squad G — Knowledge/Data
- Cloudification;
- ROSA;
- release model;
- evidence;
- knowledge curation;
- SEO knowledge pages.

### Squad H — Infrastructure/Security
- deployment;
- CI/CD;
- monitoring;
- backups;
- local agent;
- secret management.

## 13.2 Milestone 1 — Foundation

Deliver:
- monorepo;
- design system;
- auth;
- organizations;
- projects;
- PostgreSQL;
- Redis;
- storage;
- queues;
- admin shell;
- public site;
- i18n EN/DE;
- CI;
- observability;
- file pipeline.

Exit criteria:
all foundation tests green and local environment reproducible.

## 13.3 Milestone 2 — Shared intelligence

Deliver:
- engine SDK;
- evidence engine;
- dependency graph;
- knowledge graph;
- release intelligence;
- AI router;
- test lab.

Exit:
a demo engine can run end-to-end and produce a versioned finding with evidence and test.

## 13.4 Milestone 3 — Output Suite

Deliver full working:
- OPD Guard;
- FormDoctor;
- Custom Field Flow;
- Extension Impact.

Exit:
golden fixtures pass and cross-engine handoff works.

## 13.5 Milestone 4 — Migration Suite

Deliver:
- SPRO2Cloud;
- ECC2Cloud;
- Gap Radar;
- Clean Core Guard;
- ROSA/Cloudification ingestion;
- ABAP inventory.

## 13.6 Milestone 5 — Integration/Release

Deliver:
- Change Pointer;
- API Change;
- Transport/Software Collection;
- project release gate.

## 13.7 Milestone 6 — Operations/MFS

Deliver remaining modules with real fixture-based logic, not empty screens.

## 13.8 Milestone 7 — Commercial readiness

Deliver:
- Stripe;
- plan enforcement;
- pricing page;
- trials;
- email;
- admin analytics;
- support flow;
- security pages;
- audit;
- retention;
- feature flags;
- legal pages;
- SEO content engine.

## 13.9 Milestone 8 — Production hardening

- load tests;
- restore drill;
- penetration/security review checklist;
- accessibility audit;
- SEO crawl;
- Lighthouse/Core Web Vitals;
- dependency/SBOM review;
- error-budget dashboards;
- runbooks.

## 13.10 Definition of Done per engine

An engine is “done” only if:
1. documented purpose;
2. input schema;
3. parser/normalizer;
4. real deterministic logic;
5. finding codes;
6. evidence support;
7. fixtures;
8. unit tests;
9. integration test;
10. UI;
11. project integration;
12. report integration;
13. usage metering;
14. audit event;
15. admin visibility;
16. error handling;
17. localization;
18. docs.

## 13.11 Definition of Done for public launch

Must have:
- no broken core navigation;
- no dead primary CTA;
- no placeholder pricing;
- no unauthenticated data leak;
- no cross-tenant access;
- no public indexation of private routes;
- no critical failing test;
- working backups;
- working password/2FA flows;
- working email verification;
- working billing lifecycle;
- working cancel/export/delete account flows;
- valid sitemap/robots/canonicals;
- real SEO pages;
- working analytics consent;
- production health check;
- admin incident visibility.

## 13.12 Final handover from Astra

At the end produce:

1. `FINAL_IMPLEMENTATION_REPORT.md`
2. `DEPLOYMENT_GUIDE.md`
3. `ADMIN_GUIDE.md`
4. `USER_GUIDE.md`
5. `ENGINE_CATALOG.md`
6. `SECURITY_REVIEW.md`
7. `THIRD_PARTY_NOTICES.md`
8. `KNOWN_LIMITATIONS.md`
9. `GO_LIVE_CHECKLIST.md`
10. `ROADMAP_AFTER_V1.md`

The final report must include exact commands run and test results.

## 13.13 Final instruction to the coding agent

Do not optimize for appearing finished.

Optimize for:
- correctness;
- maintainability;
- evidence;
- coherent product UX;
- useful analysis;
- measurable quality;
- robust operations.

When you encounter ambiguity, prefer the architecture principles in this specification:
- deterministic before AI;
- evidence before assertion;
- project context over stateless chat;
- one shared graph over siloed tools;
- one coherent platform over unrelated utilities;
- secure multi-tenancy by default.

Continue until the repository contains a working end-to-end implementation and all feasible acceptance criteria have been verified.
