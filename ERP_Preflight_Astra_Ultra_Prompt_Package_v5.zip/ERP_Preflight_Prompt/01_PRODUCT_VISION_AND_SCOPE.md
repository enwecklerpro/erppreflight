# Part 01 — Product Vision, Personas, Workflows and Information Architecture

## 1.1 Product positioning

ERP Preflight is a **preflight intelligence platform for ERP change**.

The platform should answer questions such as:

- “Will this output configuration actually produce the expected email/form?”
- “Can this custom field reach the target document and form?”
- “What replaces this ECC IMG/SPRO configuration in S/4HANA Cloud Public Edition?”
- “Which legacy objects will not survive a Clean Core target?”
- “Will changing this field create the expected change pointer?”
- “Will this API migration introduce breaking changes?”
- “What will this software collection/transport break or miss?”
- “What uses this custom extension before I delete it?”
- “What will stop working if I lock this technical user?”
- “Why does this Fiori request return 403?”
- “Where did this workflow get stuck?”
- “Which account-determination combinations have no valid result?”
- “What changed after system refresh?”
- “What was the first causal divergence in an SAP EWM/MFS incident?”

The platform must support both **single-problem mode** and **project mode**.

## 1.2 Primary personas

Design explicit experiences for:

1. SAP consultant
2. SAP solution architect
3. SAP developer / ABAP Cloud developer
4. SAP integration consultant
5. SAP Public Cloud consultant
6. SAP Basis / operations engineer
7. SAP security / IAM administrator
8. SAP EWM/MFS consultant
9. Project manager / migration lead
10. Consulting partner / delivery manager
11. Enterprise reviewer/auditor
12. Platform owner/admin

Different personas should see relevant recommendations but use one consistent product.

## 1.3 Main navigation

Keep the primary product navigation simple:

- Home
- Projects
- Analyze
- Knowledge
- Reports

Secondary areas:

- Notifications
- Integrations
- Settings
- Billing
- Admin (authorized only)

Do not expose 18 modules as 18 unrelated top-level navigation items.

## 1.4 Analyze experience

The Analyze page starts with:

> **What do you want to check?**

Support:

- natural-language problem description;
- file upload;
- direct object identifier;
- project-scoped context;
- manual engine selection for experts.

The AI Problem Router classifies the request and proposes one or more engines.

Example:

Input:
`Purchase order is created but supplier email is not sent.`

Routing:
- primary: OPD Guard
- secondary: FormDoctor only if form/output artifact evidence indicates it

Input:
`I need supplier VAT number in purchase order PDF.`

Routing:
- FormDoctor
- Custom Field Flow Doctor if the field is not present in standard form data

Input:
`We are moving ECC EHP8 FI/MM/SD to S/4HANA Cloud Public Edition.`

Routing:
- ECC2Cloud
- SPRO2Cloud
- Gap Radar
- Clean Core Guard

## 1.5 Project mode

A project stores stable context such as:

- name;
- customer/organization;
- source ERP/version;
- target ERP/version;
- countries;
- modules;
- cloud/on-prem/private/public target;
- selected SAP release;
- integration landscape;
- uploaded artifacts;
- findings;
- accepted exceptions;
- tests;
- reports;
- release watches.

Example project:

- `ACME S/4HANA Cloud Migration`
- source: ECC EHP8
- target: S/4HANA Cloud Public Edition 2608
- countries: DE, FR
- modules: FI, MM, SD

Then users should not repeatedly re-enter target release or target environment.

## 1.6 Full Project Preflight

Provide an action:

> **Run Full Preflight**

It should orchestrate all relevant engines based on available artifacts and project context.

Output example:

- Objects analyzed: 1,827
- Critical: 31
- High: 74
- Medium: 119
- Passed: 1,603

Categories:
- Migration blockers
- Output problems
- Form/data-path problems
- Unsupported APIs
- Transport dependencies
- Extension dependencies
- Integration coverage gaps
- Operational risks

The user can drill from project summary → engine → finding → evidence → affected objects → suggested action → generated test.

## 1.7 Finding lifecycle

Every finding supports:

- open;
- acknowledged;
- accepted risk;
- false positive;
- resolved;
- regression test created;
- suppressed with expiry;
- assigned owner;
- due date;
- comments;
- attachments.

Persist status history.

## 1.8 Evidence-first experience

Each finding card must clearly show:

- title;
- severity;
- engine;
- status;
- verified/inferred state;
- why it matters;
- exact evidence;
- affected objects;
- target SAP release;
- suggested next action;
- official/reference source if available;
- first detected;
- last evaluated;
- “show only evidence” mode.

## 1.9 Reports

Support:

- project readiness report;
- executive report;
- technical finding report;
- migration blocker report;
- Clean Core report;
- output readiness report;
- integration readiness report;
- transport readiness report;
- audit report.

Export formats:

- PDF
- HTML
- CSV/XLSX where structured data matters
- JSON machine-readable export

Reports must be tenant-branded for Team/Enterprise plans.

## 1.10 Product differentiation

Do not compete by saying “we have AI”.

Differentiate on:

- project memory;
- exact dependency graph;
- release-aware knowledge;
- deterministic engines;
- evidence;
- cross-engine correlation;
- regression tests;
- re-evaluation on future releases;
- ability to work file-first and later connector-first;
- transparent confidence and provenance.

## 1.11 Free acquisition tools

Build lightweight public tools that generate SEO and lead acquisition without exposing the full platform:

- Clean Core Object Lookup
- T-Code / legacy object cloud lookup
- basic Fiori 403 decision tree
- public SAP error/knowledge search
- API deprecation lookup
- basic form/XML field checker

Free tools should lead naturally to:
`Create workspace → run full project analysis`.

Do not allow public tools to leak private customer knowledge.
