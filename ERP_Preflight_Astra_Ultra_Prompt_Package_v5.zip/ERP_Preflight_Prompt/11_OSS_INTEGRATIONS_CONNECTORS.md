# Part 11 — Open Source Integrations, Adapters and Connector Strategy

The platform should actively reuse strong open-source foundations instead of rebuilding generic infrastructure.

Keep each integration behind an adapter.

## 11.1 ROSA

Repository:
`ClementRingot/ROSA`

Use for:
- released SAP object lookup;
- Clean Core classification;
- successor lookup;
- compliance checks.

Integrate via:
- package/API/MCP adapter as appropriate;
- cache normalized results;
- store source/version provenance.

Do not make the rest of the product depend directly on ROSA response shapes.

## 11.2 SAP Cloudification Repository

Repository:
`SAP/abap-atc-cr-cv-s4hc`

Use as official versioned source for:
- released APIs;
- unreleased objects;
- successors;
- Clean Core classifications.

Build scheduled ingestion:
- fetch;
- checksum;
- parse;
- diff;
- persist version;
- trigger impacted release watches.

## 11.3 abaplint

Repository:
`abaplint/abaplint`

Use for:
- ABAP syntax/AST;
- code inventory;
- dependency extraction;
- table/field/class/FM references where supported.

Pin known-good versions and create compatibility tests.

## 11.4 abapGit

Repository:
`abapGit/abapGit`

Use understanding/file conventions to ingest exported ABAP repositories.

Do not require customers to run abapGit if they provide equivalent supported files.

## 11.5 SAP ABAP File Formats

Repositories:
- `SAP/abap-file-formats`
- `SAP/abap-file-formats-tools`

Use for standardized object-file representations and schemas where applicable.

## 11.6 Transport Dependency Analyzer

Repository:
`Mayur175/tr-dependency-analyser-v2`

Use/adapt:
- dependency extraction concepts;
- cross-TR conflicts;
- release-order logic.

Wrap in a platform-specific adapter and test against fixtures.

## 11.7 oasdiff

Repository:
`oasdiff/oasdiff`

Use in API Change Guard:
- breaking changes;
- contract diffs;
- OpenAPI comparison.

Normalize output to ERP Preflight finding codes.

## 11.8 SAP OData parser

Repository:
`ChrisWhealy/parse-sap-odata`

Evaluate for EDMX/OData V2 parsing support.

If Rust integration is inconvenient, either expose it as a small service or implement a compatible safe parser while preserving the same normalized schema.

## 11.9 json-rules-engine

Repository:
`CacheControl/json-rules-engine`

Use as a deterministic foundation for OPD rules where semantics fit.

Build SAP-specific rule normalization on top.

## 11.10 SAP Cloud SDK

Repository:
`SAP/cloud-sdk-js`

Use in future read-only SAP connectivity:
- destinations;
- HTTP;
- OData;
- resilience.

Keep connection credentials inside secure connector/local-agent architecture.

## 11.11 Gitleaks

Repository:
`gitleaks/gitleaks`

Use in file ingestion to detect secrets.

Normalize findings:
- detected secret type;
- location;
- redacted replacement;
- whether analysis can continue.

## 11.12 MFS PLC simulator

Repository:
`dominik-tylczynski/mfs-plc-sim`

Use as:
- protocol behavior reference;
- external simulator integration target;
- optional isolated component depending deployment/legal decision.

Keep it isolated behind `MfsSimulatorAdapter`.

## 11.13 Additional infrastructure OSS

Evaluate and use strong maintained projects where helpful:
- OpenTelemetry
- Prometheus
- Grafana
- ClamAV
- Trivy
- Syft/CycloneDX for SBOM
- MinIO for local S3-compatible storage
- Keycloak/Zitadel or standards-compatible identity components if selected
- PostHog for product analytics

Do not add dependencies only for fashion. Every dependency needs an owner, version policy and security update path.

## 11.14 Adapter conventions

Each external dependency integration should have:
- interface;
- adapter;
- version;
- health check;
- timeout;
- retry policy;
- circuit breaker where relevant;
- structured error;
- metrics;
- test fixture;
- fallback behavior.

## 11.15 Third-party update automation

Create scheduled dependency update workflow:
- detect release;
- run compatibility tests;
- open automated PR;
- require CI pass;
- update notices/SBOM.

Do not auto-deploy major-version dependency upgrades to production.
