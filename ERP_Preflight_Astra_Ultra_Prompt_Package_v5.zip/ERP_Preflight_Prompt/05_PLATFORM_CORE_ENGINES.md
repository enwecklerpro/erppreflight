# Part 05 — Shared Platform Engines

## 5.1 AI Problem Router

Purpose:
convert user intent into one or more engine recommendations.

Input:
- natural-language description;
- current project context;
- artifact metadata;
- optional selected object.

Output:
- suggested engines;
- confidence;
- why;
- additional required inputs.

The router must never fabricate a finding. It only routes.

## 5.2 Evidence Engine

Responsibilities:
- attach provenance;
- verify release alignment;
- rank trust;
- detect stale evidence;
- show conflicting evidence;
- expose “evidence-only” view.

Every user-facing technical verdict should attempt to attach evidence.

## 5.3 Release Intelligence

Responsibilities:
- ingest versioned SAP metadata;
- track deprecations;
- track successors;
- track release availability;
- reevaluate saved findings;
- notify users.

Provide release-diff views.

## 5.4 Dependency Graph Engine

Common graph services:
- direct dependencies;
- transitive dependencies;
- impact radius;
- cycle detection;
- missing dependencies;
- change blast radius;
- release-order derivation;
- edge provenance.

Use it across:
- extension impact;
- transports;
- ECC2Cloud;
- forms;
- APIs;
- decommission;
- MFS where applicable.

## 5.5 Test Lab

Any finding can generate a test.

Test types:
- rule scenario test;
- schema contract test;
- API breaking-change test;
- form XML field test;
- output determination test;
- change pointer test;
- transport dependency test;
- MFS sequence test.

Test case fields:
- preconditions;
- inputs;
- expected outcome;
- source finding;
- engine;
- fixture version;
- target release.

Support:
- manual run;
- batch run;
- scheduled re-run;
- compare baseline;
- export machine-readable fixture.

## 5.6 Full Project Preflight Orchestrator

Given project context and artifacts:
- detect relevant engines;
- build dependency order;
- run safe parallel stages;
- deduplicate correlated findings;
- assign cross-engine root cause where supportable;
- produce unified report.

Example:
FormDoctor says data exists but output not generated.
OPD Guard finds missing recipient rule.
Project report should correlate rather than show two unrelated incidents.

## 5.7 File Ingestion Engine

Supported artifact families:
- CSV
- XLSX
- JSON
- XML
- XSD
- XDP
- YAML
- OpenAPI JSON/YAML
- EDMX
- ZIP
- TXT/log
- abapGit repository export
- ABAP files
- SAP metadata exports
- selected PDFs as supporting documentation

Build parsers with normalized schemas.

Never use OCR unless absolutely required. Prefer machine-readable artifacts.

## 5.8 Secret Sanitization

Detect and redact:
- Authorization headers;
- bearer tokens;
- API keys;
- passwords;
- client secrets;
- cookies;
- private keys;
- common connection strings.

Store redaction metadata so analysis can explain that values were redacted.

## 5.9 Report Engine

Use structured report definitions, not ad-hoc HTML.

Reports include:
- title;
- scope;
- release;
- summary;
- statistics;
- findings;
- evidence;
- remediation;
- tests;
- appendices;
- tool versions.

Generate PDF/HTML/JSON/CSV as appropriate.

## 5.10 Notification Engine

Channels:
- in-app;
- email;
- webhook;
- later Teams/Slack adapters.

Events:
- analysis complete;
- critical finding;
- release watch changed;
- test failed;
- connector unhealthy;
- subscription/usage threshold.

## 5.11 Rules Platform

Rules must be:
- versioned;
- testable;
- reviewable;
- tenant-overridable where safe;
- publishable.

Rule lifecycle:
Draft → Review → Approved → Published → Deprecated.

Never edit active rules without a version.

## 5.12 Engine SDK

Create an internal SDK so new engines can implement:
- metadata;
- input schema;
- supported file types;
- execution;
- finding codes;
- test generation;
- health checks;
- metrics.

This keeps future modules consistent.
