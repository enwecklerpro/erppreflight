# Part 03 — Technical Architecture, Stack and Repository Structure

## 3.1 Architecture goals

The architecture must support:
- multi-tenant SaaS;
- large file analyses;
- background workers;
- deterministic engine execution;
- pluggable AI providers;
- pluggable SAP connectors;
- file-first usage;
- optional enterprise local agent;
- versioned SAP knowledge;
- dependency graph;
- release re-evaluation;
- high-quality admin;
- later horizontal scaling.

Avoid premature microservice fragmentation. Build clear module boundaries so services can be extracted later.

## 3.2 Preferred stack

### Frontend
- current stable Next.js
- React
- TypeScript
- Tailwind CSS
- shadcn/ui or equivalent accessible primitives
- TanStack Query where useful
- server components/SSR/SSG used intentionally

### Main backend
- current Node.js LTS
- NestJS
- TypeScript
- REST APIs
- generated OpenAPI documentation
- structured validation

### Analysis
- Python 3 current stable
- FastAPI for analysis service interfaces
- Pydantic
- Polars/Pandas depending workload
- lxml/defusedxml for safe XML work
- dedicated parsers per artifact type

### Persistence
- PostgreSQL as canonical source of truth
- pgvector for semantic retrieval
- Redis for cache, locks and job coordination
- S3-compatible object storage
- OpenSearch for large-scale public/private search when enabled
- optional Neo4j as derived graph projection, never canonical source of truth

### Queues
- BullMQ or equivalent robust Node queue
- Python workers invoked through job contracts
- idempotent job execution

### Infrastructure
- Docker
- Docker Compose for local development
- Terraform for production infrastructure
- Kubernetes/ECS/Container Apps-compatible containers
- Coolify-compatible deployment for early environments

## 3.3 Monorepo

Use pnpm workspaces + Turborepo or Nx. Select one and document the decision.

Recommended structure:

```text
erppreflight/
├─ apps/
│  ├─ web/
│  ├─ api/
│  ├─ admin/
│  ├─ docs/
│  └─ local-agent/
├─ services/
│  ├─ analysis-python/
│  ├─ ai-gateway/
│  ├─ search-indexer/
│  └─ knowledge-sync/
├─ engines/
│  ├─ opd/
│  ├─ forms/
│  ├─ custom-fields/
│  ├─ spro2cloud/
│  ├─ ecc2cloud/
│  ├─ gap-radar/
│  ├─ clean-core/
│  ├─ change-pointer/
│  ├─ api-change/
│  ├─ transport/
│  ├─ extension-impact/
│  ├─ decommission/
│  ├─ fiori403/
│  ├─ workflow/
│  ├─ iam-cost/
│  ├─ account-determination/
│  ├─ system-refresh/
│  └─ mfs/
├─ packages/
│  ├─ ui/
│  ├─ schemas/
│  ├─ database/
│  ├─ auth/
│  ├─ tenancy/
│  ├─ audit/
│  ├─ billing/
│  ├─ evidence/
│  ├─ jobs/
│  ├─ logging/
│  └─ config/
├─ integrations/
│  ├─ rosa/
│  ├─ cloudification/
│  ├─ abaplint/
│  ├─ abapgit/
│  ├─ oasdiff/
│  ├─ odata/
│  ├─ gitleaks/
│  ├─ sap-cloud-sdk/
│  └─ mfs-simulator/
├─ infra/
│  ├─ docker/
│  ├─ terraform/
│  ├─ k8s/
│  └─ monitoring/
└─ docs/
```

## 3.4 Service boundaries

Start with a small number of runtime services:
1. web;
2. API;
3. Node worker;
4. Python analysis service/worker;
5. PostgreSQL;
6. Redis;
7. object storage.

Do not create 30 deployment units simply because there are 18 engines.

Each engine must conform to a common internal contract.

## 3.5 Analysis engine contract

Every engine receives normalized job context:

```json
{
  "tenantId": "...",
  "projectId": "...",
  "analysisId": "...",
  "engine": "...",
  "targetRelease": "2608",
  "artifacts": [],
  "options": {}
}
```

Every engine returns:

```json
{
  "status": "completed",
  "findings": [],
  "metrics": {},
  "evidence": [],
  "artifacts": [],
  "tests": []
}
```

Create strict shared schemas.

## 3.6 Main backend owns business state

Analysis services should not arbitrarily mutate SaaS tables.

Preferred flow:
- worker sends normalized input;
- engine returns typed result;
- backend persists results transactionally.

This keeps tenancy, billing, audit and business invariants centralized.

## 3.7 File pipeline

Uploads must follow:

```text
Upload
→ tenant authorization
→ temporary quarantine
→ MIME/content validation
→ size validation
→ malware scan
→ secret scan
→ optional PII classification
→ checksum
→ encrypted object storage
→ parser
→ normalized artifact
→ analysis
```

Store original and normalized artifact metadata separately.

## 3.8 Async analysis

Never hold a normal HTTP request open for a large analysis.

Flow:
- `POST /analyses`
- return analysis/job id
- queue work
- publish progress
- persist result
- notify frontend via SSE/WebSocket/poll fallback

Frontend progress example:
- Upload validated
- Parsing artifacts
- Building dependency graph
- Running rules
- Matching evidence
- Generating tests
- Finalizing report

## 3.9 AI gateway

All model calls go through a provider abstraction.

Support:
- OpenAI
- Anthropic
- Google
- local/OpenAI-compatible endpoint
- future SAP AI Core adapter

AI gateway functions:
- routing;
- semantic mapping;
- extraction;
- explanation;
- summarization;
- document interpretation;
- translation.

Record:
- model;
- provider;
- tokens;
- latency;
- cost;
- purpose;
- tenant;
- data policy used.

Never call AI directly from browser code.

## 3.10 Search

Support:
- exact object lookup;
- fuzzy object lookup;
- full-text knowledge search;
- semantic search;
- evidence search;
- project-scoped search.

Use PostgreSQL full text + pgvector initially, and OpenSearch when scale justifies it.

## 3.11 Connector abstraction

Define connectors independently from engines:

- file connector;
- OData connector;
- HTTP/OpenAPI connector;
- SAP Public Cloud connector;
- SAP Private/On-Prem connector;
- BTP connector;
- RFC connector through local agent where appropriate;
- Git connector;
- future Cloud Connector adapter.

Engines should consume normalized data, not raw connector-specific protocols.

## 3.12 Local Agent

Build a Docker-packaged local agent for enterprise use.

Responsibilities:
- read-only collection inside customer network;
- local parsing where configured;
- secret redaction;
- optional anonymization;
- outbound-only secure connection;
- signed job instructions;
- tenant/device enrollment;
- automatic update support;
- health reporting.

Allow “analysis stays local” mode later.

## 3.13 API

Use versioned REST APIs:
- `/api/v1/...`

Generate OpenAPI.

Expose webhook events for enterprise automation later.

## 3.14 Idempotency

Uploads, jobs, webhooks and billing events must be idempotent.

Use idempotency keys.

## 3.15 Feature flags

Implement centralized feature flags from early stages:
- by environment;
- plan;
- tenant;
- user percentage;
- beta cohort.

Admin can enable modules without redeploying.

## 3.16 Configuration

Use typed config validation.

No silent fallback for critical secrets.

Provide:
- `.env.example`
- local defaults
- production config docs
- secrets-manager integration guidance.
