# Part 12 — Testing, QA, CI/CD, Observability and Production Operations

## 12.1 Testing pyramid

### Unit
- parsers;
- rules;
- graph functions;
- billing calculations;
- permissions;
- redaction;
- normalization.

### Contract tests
- engine contracts;
- external OSS adapter output;
- connector interfaces;
- AI gateway schemas.

### Integration
- PostgreSQL;
- Redis;
- object storage;
- queue;
- API;
- knowledge ingestion.

### End-to-end
Critical flows:
- signup;
- create org;
- create project;
- upload;
- run analysis;
- see finding/evidence;
- generate test;
- export report;
- subscription;
- admin review.

Use Playwright for browser E2E.

## 12.2 Golden fixtures

Each engine needs versioned golden test fixtures.

Examples:
OPD:
- valid;
- no recipient;
- overlap;
- unreachable;
- default rule.

Forms:
- field in XML and correctly bound;
- in XML but wrong binding;
- missing from XML;
- namespace issue.

SPRO2Cloud:
- exact mapping;
- partial;
- unsupported;
- unknown.

Clean Core:
- released;
- successor;
- no successor;
- mixed repo.

Change Pointer:
- covered;
- configured but no runtime;
- custom field missing.

API:
- non-breaking addition;
- required field added;
- type changed;
- endpoint removed.

MFS:
- normal;
- missing ACK;
- duplicate;
- wrong CP;
- out of order;
- retry storm.

## 12.3 AI evaluation

LLM-assisted tasks need evaluation datasets.

Track:
- routing accuracy;
- extraction accuracy;
- explanation factuality;
- unsupported claims.

The deterministic finding remains source of truth.

## 12.4 CI

GitHub Actions:
- install;
- lint;
- type check;
- unit test;
- integration test;
- Python lint/type/test;
- DB migration check;
- OpenAPI compatibility;
- dependency vulnerability scan;
- secret scan;
- container scan;
- build;
- E2E smoke where feasible.

Block merge on failures.

## 12.5 Preview environments

Create per-PR preview for web/API when infrastructure permits.

Use sanitized test data only.

## 12.6 Database migrations

- forward migrations;
- migration tests;
- backup before risky production migration;
- no manual schema drift.

## 12.7 Backups

Document and automate:
- PostgreSQL backups;
- point-in-time recovery target;
- object-storage versioning;
- configuration backup.

Run restore drills.

## 12.8 Observability

Use OpenTelemetry.

Collect:
- traces;
- metrics;
- structured logs.

Dashboards:
- API latency;
- engine duration;
- queue lag;
- job failures;
- DB pool;
- Redis;
- storage;
- search;
- AI provider latency/cost;
- connector health;
- source sync freshness.

## 12.9 Sentry/error tracking

Integrate frontend/backend error tracking with:
- release;
- environment;
- tenant-safe identifiers;
- no raw private payloads.

## 12.10 Health endpoints

Provide:
- liveness;
- readiness;
- dependency health;
- knowledge source freshness;
- worker health.

## 12.11 Runbooks

Write runbooks for:
- database outage;
- queue stuck;
- AI provider outage;
- object storage outage;
- source sync failure;
- connector compromise;
- billing webhook failure;
- leaked secret;
- corrupted knowledge import.

## 12.12 Performance

Targets should be measured, not guessed.

Implement load tests for:
- concurrent project dashboards;
- large OPD scenario batches;
- API diff;
- ABAP inventory;
- large MFS logs.

Use streaming/chunked parsers where necessary.

## 12.13 Large file strategy

Never load multi-GB logs fully into memory.

Use:
- streaming;
- chunking;
- columnar processing;
- temporary files;
- bounded memory.

## 12.14 Reliability

Background jobs:
- idempotent;
- retryable;
- dead-letter queue;
- timeout;
- cancellation;
- progress.

## 12.15 Security CI

Run:
- Gitleaks;
- dependency audit;
- Trivy/container scan;
- SAST where useful;
- SBOM generation.

## 12.16 Release process

Environments:
- local;
- dev;
- staging;
- production.

Production releases:
- tagged;
- changelog;
- database migration plan;
- rollback plan;
- smoke test;
- health verification.

## 12.17 Status page

Provide public operational status endpoint/page.

Do not expose sensitive internal details.
