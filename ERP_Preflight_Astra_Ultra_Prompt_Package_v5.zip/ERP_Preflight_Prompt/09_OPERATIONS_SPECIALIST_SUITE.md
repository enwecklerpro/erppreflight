# Part 09 — Operations, IAM, Troubleshooting and Warehouse Specialist Suite

## 9.1 Safe Decommission Preflight

### Goal
Before locking/deleting a user, technical user, RFC destination, job identity or service account, identify what can break.

Analyze where data is available:
- background jobs;
- job steps;
- RFC destinations;
- workflows/work items;
- interfaces;
- scheduled integrations;
- technical ownership;
- last activity;
- roles.

Output:
- risk;
- direct dependencies;
- last observed usage;
- reassignment checklist;
- re-run preflight after remediation.

Support file-based inventory first and connector-based collection later.

## 9.2 Fiori 403 Root-Cause Doctor

Inputs may include:
- HTTP response;
- `/IWFND/ERROR_LOG` export;
- SU53 trace;
- ICF service state;
- Gateway logs;
- UCON information;
- CSRF request details;
- BTP destination;
- Cloud Connector status;
- browser/network export.

Decision tree/rules:
- authorization;
- ICF inactive;
- OData activation;
- UCON blocked;
- CSRF/auth;
- destination;
- Cloud Connector;
- session/browser issue;
- unknown.

Output:
- likely root area;
- evidence;
- next diagnostic action;
- what data is missing.

Never present a guess as proven.

## 9.3 Workflow Stuck Explainer

Inputs:
- workflow/work item export;
- error text;
- agent resolution data;
- event trace;
- container data where safe.

Functions:
- stuck step;
- no agent;
- failed task;
- missing event;
- dead-end;
- overdue;
- restart candidate;
- manual intervention candidate.

Output safe diagnostics. Do not auto-cancel/forward without a future explicit privileged connector and user confirmation.

## 9.4 IAM Cost Optimizer

Purpose:
model authorization design and cost/privilege impact.

Inputs:
- business roles;
- catalogs;
- IAM apps;
- actual usage where available;
- price-category metadata/configuration supplied by customer/knowledge;
- read-only alternatives.

Functions:
- least-privilege suggestions;
- redundant catalogs;
- unused role content;
- alternative role composition;
- modeled price-category impact;
- role-risk comparison.

Clearly label cost estimates and assumptions. Do not present contract/licensing interpretation as legal fact.

## 9.5 Account Determination Preflight

Do not duplicate standard one-document analysis only.

Focus on **bulk coverage before go-live/change**.

Inputs:
- valuation classes;
- movement types;
- account modifiers;
- plants/company codes;
- relevant config combinations;
- expected account rules.

Output:
- combinations with no account;
- conflicting combinations;
- suspicious catch-all/default;
- coverage matrix;
- regression scenarios.

Support SD/FI/MM variants through separate rule models.

## 9.6 System Refresh Delta Guard

Purpose:
compare system-specific configuration before and after refresh/copy.

Track examples:
- RFC destinations;
- logical systems;
- printers;
- jobs;
- endpoints;
- email settings;
- integration destinations;
- environment-specific URLs;
- queues;
- selected custom config.

Flow:
1. capture baseline;
2. capture post-refresh;
3. compare;
4. apply allow/ignore policy;
5. generate repair checklist.

Do not attempt destructive automatic repair by default.

## 9.7 MFS BlackBox

### Goal
Analyze SAP EWM/MFS incident logs and identify the first causal divergence, not only the final visible error.

Inputs:
- CSV/XLSX/TXT MFS logs;
- optional telegram specification;
- route/communication-point model;
- optional simulator fixture.

Core:
- parse telegrams;
- reconstruct HU/WT state;
- ACK/retry timing;
- sequence handling;
- source/destination;
- communication point;
- channel;
- PLC;
- life telegram;
- missing completion;
- impossible jump;
- duplicate;
- out-of-order;
- wrong confirmation;
- retry storm.

### Key result
- visible failure;
- first divergence;
- root event;
- subsequent consequences;
- evidence chain.

### Advanced
- incident clustering;
- fingerprint recurrence;
- minimal reproduction;
- regression test generation;
- before/after PLC software-release behavior.

The AI can explain the result but does not determine the state-machine violation.

## 9.8 MFS simulator integration

Keep simulator integration behind an adapter.

Support:
- export reproduction scenario;
- invoke compatible external simulator when configured;
- import simulator result.

Do not tightly couple the platform’s entire architecture to one simulator implementation.
