# Part 04 — PostgreSQL Model, Knowledge Graph, Dependency Graph and Release Intelligence

## 4.1 Canonical database

PostgreSQL is the canonical system of record.

Use migrations and explicit constraints.

Every tenant-owned business table must be safely tenant-scoped.

Use PostgreSQL Row Level Security where practical as defense in depth in addition to application authorization.

## 4.2 Core SaaS entities

Implement at minimum:

- users
- identities
- organizations
- organization_members
- roles
- permissions
- plans
- subscriptions
- billing_customers
- usage_events
- usage_limits
- projects
- project_members
- project_environments
- sap_system_profiles
- uploaded_files
- normalized_artifacts
- analyses
- analysis_runs
- findings
- finding_status_history
- finding_comments
- finding_assignments
- evidence_items
- recommendations
- test_cases
- test_runs
- reports
- notifications
- release_watches
- audit_events

## 4.3 Knowledge entities

Represent SAP/ERP knowledge with version-aware records:

- knowledge_objects
- knowledge_object_versions
- object_aliases
- object_relationships
- sap_releases
- product_editions
- application_components
- business_objects
- fields
- cds_views
- APIs
- API_versions
- BAdIs
- business_contexts
- business_scenarios
- SSCUIs
- CBC_activities
- scope_items
- Fiori_apps
- business_catalogs
- IAM_apps
- form_data_sources
- form_templates
- output_types
- change_pointer_message_types
- tables
- function_modules
- BAPIs
- IDoc_types
- transaction_codes
- IMG_activities
- known_gaps
- known_limitations
- deprecations
- successor_mappings
- evidence_sources

Do not force every type into one enormous JSON blob. Use a base object model plus typed extensions.

## 4.4 Relationship graph

Core relationship examples:

- `DEPENDS_ON`
- `USED_BY`
- `EXPOSED_BY`
- `SUCCESSOR_OF`
- `REPLACES`
- `RELATED_TO`
- `MAPPED_TO`
- `EXTENDS`
- `PROPAGATES_TO`
- `CONTROLLED_BY`
- `TRANSPORTED_IN`
- `REQUIRES`
- `BLOCKED_BY`
- `AVAILABLE_IN_RELEASE`
- `DEPRECATED_IN_RELEASE`
- `SUPPORTED_BY`
- `CONSUMES`
- `PRODUCES`

Each edge stores:
- source object;
- target object;
- relationship;
- valid from/to release;
- confidence;
- evidence source;
- reviewed status;
- tenant/global scope;
- created/updated timestamps.

## 4.5 Customer dependency graph

Customer-specific objects are separate from global SAP knowledge.

Examples:
- YY1 custom field;
- Z class;
- custom form;
- software collection;
- custom API;
- job;
- technical user;
- RFC destination.

Customer edge data must never become public/global knowledge automatically.

Provide an explicit anonymized/approved contribution workflow only if desired later.

## 4.6 Graph projection

PostgreSQL remains canonical.

If Neo4j is enabled:
- project selected nodes/edges to Neo4j;
- rebuild projection from canonical data;
- never make Neo4j the only source of truth;
- use it for deep traversal/impact visualization.

## 4.7 Evidence model

Every knowledge fact/finding can have multiple evidence records.

Evidence fields:
- source type;
- source URL/reference;
- source title;
- publisher;
- publication/update date;
- retrieved date;
- target release;
- excerpt hash;
- internal note;
- trust level;
- reviewer;
- status;
- superseded-by.

Trust levels:
- official product metadata/repository
- official product documentation
- official support knowledge
- official community content
- curated internal rule
- third-party reference
- customer evidence
- inferred

The UI must distinguish these.

## 4.8 Release-aware facts

Do not store:
`Object X is supported = true`

Store:
`Object X support state for product/edition/release Y`.

The same requirement may be:
- blocked in 2602;
- supported in 2608.

Create a reusable release comparison service.

## 4.9 Release Watch

Users can watch:
- object;
- requirement;
- finding;
- API;
- successor mapping;
- unsupported gap.

When knowledge sync updates:
- re-evaluate affected watches;
- generate change event;
- notify tenant;
- show “gap closed”, “new deprecation”, “successor changed”, etc.

## 4.10 Finding model

A finding must contain:
- engine;
- code;
- title;
- severity;
- confidence class;
- message;
- technical details;
- affected objects;
- evidence;
- recommendations;
- project context;
- release;
- first seen;
- last evaluated;
- engine version;
- rule version;
- AI explanation model/version if used.

This allows reproducibility.

## 4.11 Suppression and accepted risk

Support suppression:
- permanent;
- until date;
- until release;
- until object changes.

Require a reason and audit it.

## 4.12 Knowledge review workflow

Admin/curators:
- draft knowledge item;
- attach evidence;
- request review;
- approve;
- publish;
- deprecate;
- supersede.

Do not let an unreviewed LLM-generated fact silently enter verified global knowledge.

## 4.13 Search indexing

Create search documents from:
- objects;
- aliases;
- descriptions;
- evidence;
- related business concepts;
- user questions;
- release metadata.

Keep index rebuild scripts deterministic.

## 4.14 Public knowledge pages

Only global reviewed knowledge can generate public SEO pages.

Tenant/customer objects are never public.
