# Part 02 — Brand, UX, Visual Design, Public Website and SEO

## 2.1 Brand

Name: **ERP Preflight**

Primary domain:
`https://erppreflight.com`

Brand promise:
> **Know what will break before production does.**

Alternative marketing line:
> Preflight your ERP changes before they become production incidents.

The product should feel:
- precise;
- calm;
- technical;
- trustworthy;
- enterprise-grade;
- modern;
- fast;
- not flashy;
- not visually derivative of SAP.

## 2.2 Visual system

Create a proprietary visual identity.

Suggested palette:

- Midnight: `#0B1220`
- Deep surface: `#111A2D`
- Primary blue: `#2F6BFF`
- Cyan accent: `#2BB7FF`
- Mint/success accent: `#18C6A3`
- Success: `#16A34A`
- Warning: `#F59E0B`
- Critical: `#E5484D`
- Light background: `#F7F9FC`
- White: `#FFFFFF`
- Muted text: accessible slate tones

Use accessible contrast and verify WCAG AA.

Typography:
- UI: Geist or Inter
- technical/code: JetBrains Mono or a similarly legible monospace

Provide both light and dark mode.

## 2.3 Logo

Create original SVG logo assets:
- full horizontal mark;
- icon-only;
- monochrome;
- dark/light versions;
- favicon.

Visual concept should suggest:
- preflight check;
- dependency graph;
- verification/gate;
- forward motion.

Avoid literal copying of aviation or SAP visual assets.

## 2.4 Product UI

Use a polished design system based on:
- React
- Tailwind CSS
- shadcn/ui or equivalent accessible primitives
- consistent design tokens
- responsive layouts
- keyboard accessibility
- command palette
- tooltips for SAP terminology
- dense/comfortable data table modes

Important UI components:
- severity badges;
- evidence chips;
- dependency graph visualization;
- file drop zones;
- analysis progress stepper;
- project health summary;
- rule diff viewer;
- object inspector;
- finding drawer;
- report preview;
- timeline view;
- test-run console;
- audit timeline;
- admin metric cards.

Never make dashboard screens look like generic template SaaS.

## 2.5 Core homepage

Hero:

**ERP Preflight**

> Know what will break before production does.

Subheadline:
> Validate ERP outputs, extensions, integrations, transports, migrations and operational changes before they fail.

CTAs:
- `Run a Preflight`
- `Explore free tools`

Sections:
1. problem statement;
2. how it works;
3. six solution areas;
4. evidence-backed analysis;
5. project mode;
6. release intelligence;
7. security/privacy;
8. integrations/open standards;
9. pricing;
10. FAQ;
11. final CTA.

## 2.6 Solution pages

Create high-quality pages for:

- `/solutions/output-forms`
- `/solutions/cloud-migration`
- `/solutions/clean-core`
- `/solutions/integration`
- `/solutions/release-transport`
- `/solutions/operations`
- `/solutions/warehouse-automation`

Each page:
- explains the pain;
- shows relevant engines;
- includes examples;
- links to relevant knowledge pages;
- contains strong CTA;
- avoids unverifiable ROI claims.

## 2.7 Internationalization

Launch with:
- English
- German

URL strategy:
- `/en/...`
- `/de/...`

Use proper `hreflang`.

Do not use machine-translated low-quality content for SEO. Translation keys and content workflow must support human review.

## 2.8 SEO architecture

SEO is a first-class product capability.

Create server-rendered/static indexable pages for high-intent problem/object queries.

Examples:

### Output
- `/en/sap/output/purchase-order-email-not-sent`
- `/en/sap/output/opd-no-rule-match`
- `/en/sap/forms/custom-field-not-showing-in-pdf`
- `/en/sap/forms/adobe-form-xml-binding`

### Migration
- `/en/sap/cloud/migration/f-59`
- `/en/sap/cloud/migration/va01`
- `/en/sap/cloud/migration/me21n`

### Clean Core
- `/en/sap/clean-core/mara`
- `/en/sap/clean-core/bseg`
- `/en/sap/clean-core/i-product`

### Integration
- `/en/sap/change-pointers/matmas`
- `/en/sap/api/deprecations/...`

## 2.9 Programmatic SEO quality controls

Never publish thin pages solely because an object exists in the database.

A page is indexable only if it has enough verified information:
- object name/type;
- purpose;
- relevant release;
- status;
- successor/alternative if applicable;
- evidence/source;
- related objects;
- actionable explanation;
- last verified date.

Low-information pages should be `noindex` until enriched.

Generate:
- sitemap indexes split by content type;
- image sitemap when relevant;
- RSS/Atom for release knowledge updates where useful.

## 2.10 Structured data

Use appropriate Schema.org:
- Organization
- SoftwareApplication
- WebApplication
- TechArticle
- FAQPage where content genuinely matches FAQ
- BreadcrumbList

## 2.11 Technical SEO

Implement:
- canonical URLs;
- clean semantic HTML;
- strong Core Web Vitals;
- optimized fonts;
- SSR/SSG where appropriate;
- no blocking client-only content for critical SEO pages;
- robots.txt;
- dynamic sitemap;
- 404/410 handling;
- redirects registry;
- Open Graph/Twitter metadata;
- metadata templates;
- search-friendly internal linking.

## 2.12 Internal linking from the knowledge graph

Object relationships should also power SEO links.

Example:
MARA page links to:
- I_PRODUCT
- Product Master
- ABAP Cloud
- ECC2Cloud
- relevant API pages.

Use related-content modules that are actually graph-derived.

## 2.13 Content system

Provide a content/knowledge publishing workflow:
- draft;
- technical review;
- SEO review;
- publish;
- update required;
- deprecated.

Public pages must show:
- last reviewed;
- target release;
- source provenance.

## 2.14 Analytics

Integrate privacy-aware analytics:
- product events;
- conversion funnel;
- free-tool usage;
- signup;
- activation;
- first analysis;
- report export;
- subscription conversion.

Support PostHog or an abstraction that can use PostHog.

Consent must be respected for non-essential tracking.

## 2.15 Legal/public pages

Include:
- Privacy Policy
- Terms
- Imprint/Impressum
- Cookie settings
- Security page
- Subprocessors page
- DPA request page
- Status page link
- Trademark/independence disclaimer

Use wording indicating the product is independent and not affiliated with or endorsed by SAP SE. Final legal copy can be reviewed later, but the pages, CMS and placeholders must be structurally complete.
