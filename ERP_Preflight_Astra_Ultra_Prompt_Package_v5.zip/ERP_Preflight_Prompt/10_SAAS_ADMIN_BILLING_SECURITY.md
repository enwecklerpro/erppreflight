# Part 10 — SaaS, Admin Console, Billing, Security, Compliance and Customer Management

## 10.1 Multi-tenancy

Organization-based tenancy.

Roles:
- Platform Owner
- Platform Admin
- Organization Owner
- Organization Admin
- Project Manager
- Architect
- Consultant
- Developer
- Reviewer
- Viewer
- Billing Admin
- Security Admin

Implement granular permissions, not only role-name checks.

## 10.2 Authentication

Support:
- email/password with strong hashing;
- magic link;
- OAuth/OIDC providers;
- TOTP 2FA;
- recovery codes;
- session/device management.

Enterprise:
- SAML/OIDC SSO;
- SCIM provisioning;
- enforce MFA;
- IP allowlists where applicable.

Abstract identity provider to avoid hard lock-in.

## 10.3 Plans

Create configurable plans:
- Free
- Pro
- Consultant
- Team
- Enterprise

Feature/limit examples:
- analyses/month;
- project count;
- storage;
- file size;
- AI credits;
- team members;
- report branding;
- release watches;
- connectors;
- local agent;
- SSO/SCIM;
- retention;
- private AI.

Plan definitions must be admin-configurable.

## 10.4 Billing

Integrate Stripe behind a billing provider abstraction.

Implement:
- checkout;
- customer portal;
- subscriptions;
- upgrades/downgrades;
- trials;
- coupons;
- credits;
- invoices;
- failed-payment handling;
- webhooks;
- idempotency;
- tax metadata.

Maintain internal entitlement state derived from verified billing events.

## 10.5 Usage metering

Meter:
- analyses;
- engine runs;
- AI tokens/cost;
- storage;
- API calls;
- connector activity;
- report generation;
- large-log processing.

Show usage to user and admin.

## 10.6 Super Admin dashboard

Provide operational and business overview:
- MRR;
- ARR;
- trials;
- conversion;
- churn;
- active orgs;
- active users;
- analyses/day;
- storage;
- AI spend;
- infrastructure cost;
- gross margin estimate;
- error rate;
- queue depth;
- source sync freshness.

## 10.7 Organization admin

Platform admins can:
- inspect organization;
- suspend/reactivate;
- change plan;
- extend trial;
- grant credits;
- adjust limits;
- manage feature flags;
- view usage;
- view billing state;
- view support history.

## 10.8 Safe impersonation

Admin impersonation:
- requires privileged permission;
- requires reason;
- banner during session;
- fully audited;
- cannot access decrypted secrets unnecessarily.

## 10.9 Knowledge Admin

Screens for:
- object records;
- mappings;
- sources;
- evidence;
- release validity;
- last verification;
- conflicts;
- review queue;
- publish/deprecate.

## 10.10 Rule Admin

Manage:
- engine;
- rule id;
- version;
- status;
- tests;
- coverage;
- author;
- reviewer.

Publishing requires tests to pass.

## 10.11 AI Admin

Configure per task:
- primary model;
- fallback;
- max tokens;
- temperature where applicable;
- provider;
- privacy mode;
- cost ceiling.

Global kill switch per provider.

## 10.12 Source Sync Admin

Manage:
- source adapters;
- last sync;
- freshness;
- errors;
- item counts;
- changed records;
- retry.

Alert if a critical knowledge source becomes stale.

## 10.13 OSS / Third-party Admin

Maintain:
- dependency;
- version;
- repository;
- license identifier;
- attribution;
- modified/not modified;
- update available;
- security advisory;
- deployment mode.

Generate SBOM and third-party notices.

Do not let licensing questions block implementation; maintain accurate inventory so commercial/legal review is straightforward.

## 10.14 Support console

Ticket contains:
- org;
- project;
- engine;
- finding;
- analysis run;
- engine version;
- rule version;
- sanitized input metadata;
- logs;
- user report.

Allow “report incorrect result” from finding UI.

## 10.15 Audit logs

Audit:
- login/security event;
- file upload/download/delete;
- rule/knowledge edits;
- admin actions;
- impersonation;
- connector creation;
- billing overrides;
- report export;
- secret changes;
- permission changes.

Audit records should be tamper-evident and immutable from normal application roles.

## 10.16 File retention

Tenant-configurable:
- delete immediately after analysis;
- 24 hours;
- 7 days;
- 30 days;
- enterprise custom.

Knowledge derived from files must respect deletion policy and privacy mode.

## 10.17 Encryption and secrets

- TLS everywhere;
- encrypted storage;
- encrypted secrets;
- KMS/provider abstraction;
- rotate credentials;
- no secrets in logs;
- no secrets in Git.

## 10.18 Security pipeline

Upload:
- MIME sniff;
- archive bomb protection;
- malware scan;
- secret scan;
- XML entity protection;
- path traversal protection;
- file-size limits;
- zip nesting limits.

App:
- CSP;
- CSRF protection;
- rate limiting;
- brute-force protection;
- secure cookies;
- CORS policy;
- tenant boundary tests.

## 10.19 Privacy/GDPR

Implement:
- consent controls;
- data export request flow;
- account deletion request;
- organization retention policy;
- subprocessors registry;
- DPA workflow placeholder;
- EU-friendly data-region abstraction.

## 10.20 Enterprise security page

Provide public `/security` with:
- encryption;
- privacy;
- tenant isolation;
- backups;
- responsible disclosure;
- subprocessor link;
- contact.

Do not claim certifications not actually obtained.
