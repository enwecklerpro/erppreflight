# Part 06 — Output & Extensibility Suite

## 6.1 OPD Guard / Output Determination Doctor

### Goal
Evaluate output-parameter rules before production and explain why expected output is or is not determined.

### Inputs
Support normalized imports from:
- CSV/XLSX exports;
- JSON;
- manually entered scenario/rules;
- future connector.

Model steps such as:
- Output Type
- Receiver
- Channel
- Printer/Print Queue
- Email Recipient
- Form Template
- Output Relevance

### Core functions
- exact scenario simulation;
- first failed step;
- matched rule;
- rule trace;
- wildcard/blank handling;
- priority/order handling;
- conflicting rules;
- overlapping rules;
- unreachable/shadowed rules;
- missing default;
- incomplete coverage;
- duplicate outcome;
- batch scenario testing;
- before/after rule diff;
- generated regression matrix.

### Example output
For scenario:
- company code 1000
- purchasing org DE01
- purchasing group 001
- supplier 100045

Show:
- Output Type matched row 12
- Receiver matched row 4
- Channel matched row 19 = EMAIL
- Email Recipient = no rule match
- first failed step = Email Recipient
- exact missing condition

### Important
Implement SAP-specific semantics on top of a generic deterministic rules engine. Do not ask an LLM to decide which row wins.

## 6.2 FormDoctor / OutputPath

### Goal
Trace a desired field from business data to output payload to form binding.

### Inputs
- XML
- XSD
- XDP
- metadata
- form-data-source information
- custom field metadata
- user requirement

### Core questions
- Is the field in the business source?
- Is it in the output XML/XSD?
- Is a data-source extension needed?
- Is a custom field needed?
- Is a BAdI needed to populate it?
- Does the XDP bind to the correct path?
- Does the layout hide/format it incorrectly?
- Is the requested behavior unsupported?

### Deterministic checks
- XML node existence;
- XSD path existence;
- namespace resolution;
- XDP binding path resolution;
- mismatched path;
- duplicate bindings;
- data present but bound elsewhere;
- data absent from XML;
- type/format mismatch.

### Output
- data path visualization;
- exact break point;
- supported route;
- evidence;
- action checklist.

## 6.3 Custom Field Flow Doctor

### Goal
Determine whether a custom field can propagate from one business process stage to another.

Example:
Purchase Order Item → Supplier Invoice → Journal Entry → output form.

### Capabilities
- source context;
- target context;
- standard propagation scenario;
- missing propagation;
- relevant BAdI/custom logic requirement;
- API exposure;
- form exposure;
- analytics exposure;
- UI usage;
- known release limitations.

Visualize the flow and mark:
- supported;
- partial;
- custom logic;
- blocked;
- unknown.

## 6.4 Extension Impact Guard

### Goal
Before changing/deleting an extension, show the blast radius.

Objects:
- custom field;
- custom CDS;
- custom logic/BAdI;
- app variant;
- custom API;
- form;
- extension item;
- software collection.

### Output
Direct and indirect consumers:
- forms;
- APIs;
- CDS;
- UI;
- analytics;
- collections;
- business logic;
- integrations.

Actions:
- “Can I delete this?”
- “Can I change type/length?”
- “What must be transported with it?”
- “Which tests must rerun?”

Generate regression test recommendations.

## 6.5 Shared Output Suite UX

A user should be able to move seamlessly:

FormDoctor finding:
`Field exists and binding is correct, but no output document is produced`

CTA:
`Check Output Determination`

OPD Guard:
`Channel is EMAIL but recipient rule does not match`

This cross-engine handoff is mandatory.

## 6.6 Output Suite test fixtures

Create realistic fixtures:
- valid PO output;
- missing email recipient;
- conflicting rules;
- unreachable rule;
- missing XML field;
- wrong XDP binding;
- custom field requiring custom logic;
- unsupported scenario.

Include deterministic expected outcomes.
