# Part 07 — Migration & Clean Core Suite

## 7.1 SPRO2Cloud

### Goal
Map ECC/S/4 legacy IMG/SPRO configuration to S/4HANA Cloud Public Edition configuration concepts.

Inputs:
- IMG activity id/name;
- SPRO path;
- uploaded inventory;
- source release;
- target release;
- country;
- module.

Output status:
- EXACT
- PARTIAL
- SCOPE_DEPENDENT
- PROCESS_REDESIGN
- NOT_AVAILABLE
- NEEDS_REVIEW

For mapped targets include:
- SSCUI/CBC activity;
- scope item;
- country dependencies;
- relevant catalogs/roles where known;
- evidence;
- release;
- differences from legacy.

Support bulk XLSX/CSV assessment.

## 7.2 ECC2Cloud Navigator

### Goal
Perform broad legacy artifact assessment.

Inputs:
- T-Code usage;
- IMG inventory;
- ABAP source/abapGit;
- tables/fields;
- FMs/BAPIs;
- IDocs;
- custom objects;
- interfaces;
- business requirements.

Outputs:
- directly supported;
- successor available;
- extension required;
- process redesign;
- no equivalent;
- needs review.

Aggregate blockers by:
- module;
- severity;
- object type;
- business process;
- owner.

Do not pretend every legacy object has a 1:1 cloud replacement.

## 7.3 SAP Gap Radar

### Goal
Answer:
“Can the target SAP cloud release do this requirement using a supported approach?”

Input:
natural-language business/technical requirement plus project context.

Resolution pipeline:
1. standard functionality;
2. configuration;
3. key-user extensibility;
4. developer extensibility;
5. released CDS;
6. released API;
7. BAdI/extension point;
8. event;
9. side-by-side extension;
10. supported workaround;
11. known product gap;
12. unknown/review required.

Verdicts:
- SUPPORTED_STANDARD
- SUPPORTED_CONFIGURATION
- SUPPORTED_EXTENSION
- PARTIAL
- WORKAROUND
- BLOCKED
- UNKNOWN

Attach evidence and target release.

Allow:
`Watch this requirement`

Release Intelligence re-evaluates later.

## 7.4 Clean Core Object Guard

### Inputs
- one object;
- object list;
- ABAP code;
- abapGit repo.

### Functions
- released status;
- Clean Core classification;
- successor mapping;
- deprecated object detection;
- unreleased dependency detection;
- code-level usage inventory;
- compliance percentage;
- migration suggestions.

Combine deterministic ABAP parsing with released-object repositories.

## 7.5 ABAP inventory

Use AST/static analysis rather than regex for:
- tables;
- fields;
- classes;
- interfaces;
- FMs;
- methods;
- type references;
- SQL access;
- dynamic calls where detectable.

Flag dynamic/reflection cases as uncertain.

## 7.6 Migration project report

Create:
- executive summary;
- migration blocker count;
- exact mappings;
- partial mappings;
- unknowns;
- unsupported requirements;
- Clean Core risks;
- extensions;
- priority order;
- owner assignment;
- evidence appendix.

## 7.7 Public SEO hooks

Reviewed migration mappings can generate public pages such as:
- T-Code cloud replacement pages;
- Clean Core object pages;
- SPRO/SSCUI knowledge pages.

Never expose customer-specific inventory publicly.
