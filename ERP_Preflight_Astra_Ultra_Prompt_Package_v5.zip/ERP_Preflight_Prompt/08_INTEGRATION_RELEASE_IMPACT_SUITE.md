# Part 08 — Integration, Release, Transport and Impact Suite

## 8.1 Change Pointer Coverage Auditor

### Goal
Answer not only “which change pointers exist?” but:
“Which business changes are expected to create a pointer, and which of those are not actually covered?”

Inputs:
- message type;
- expected triggering fields;
- BD61/BD50/BD52-style configuration exports;
- change-document metadata where available;
- runtime sample/pointer exports;
- reduced message type configuration;
- distribution data.

Checks:
- global activation;
- message-type activation;
- field coverage;
- change-document eligibility;
- custom field support;
- expected vs observed pointer;
- runtime missing pointer;
- duplicate/retry anomalies.

Output:
coverage matrix with VERIFIED / AT_RISK / NOT_COVERED.

Generate test cases:
“Change field X → expect message type Y pointer”.

## 8.2 API Change Guard

### Goal
Compare API/contract versions and show breaking impact for saved integrations.

Inputs:
- OpenAPI 2/3 JSON/YAML;
- OData EDMX metadata;
- normalized API snapshots;
- project field/operation usage.

Checks:
- removed endpoint;
- removed field;
- required/optional changes;
- type changes;
- length/enum changes;
- renamed navigation/property;
- changed operation;
- deprecation;
- successor API;
- coverage gaps.

Output:
- breaking/non-breaking changes;
- affected project mappings;
- migration readiness percentage;
- exact affected tests;
- successor guidance.

Support baseline snapshots and release watches.

## 8.3 Software Collection Dependency Guard

### Goal
Preflight key-user/public-cloud collection dependencies before export/import.

Analyze:
- custom fields;
- CDS;
- forms;
- app variants;
- custom logic;
- APIs;
- collection relationships;
- prerequisite artifacts.

Output:
- missing dependency;
- cross-collection dependency;
- circular dependency;
- wrong order;
- unresolved object;
- suggested grouping;
- recommended import/release order.

## 8.4 Transport Dependency Analyzer

Support classic/private/on-prem and cloud-aware transport concepts through adapters.

Analyze:
- object conflicts;
- inheritance/implementation;
- type references;
- function calls;
- same object in multiple tasks/TRs;
- release order;
- missing prerequisites.

Output graph + recommended release sequence.

## 8.5 Extension Impact Guard reuse

Transport/release suite must reuse Extension Impact edges.

If a collection contains a form that uses a custom field in another collection, the system should detect it from the common dependency graph.

## 8.6 API/project integration registry

Projects can register an integration:
- source;
- target;
- APIs;
- endpoints;
- fields consumed;
- operations used;
- auth type;
- owner;
- criticality.

API Change Guard uses this registry to report real impact rather than generic diffs.

## 8.7 Release gate

Provide project-level status:

- CLEAR
- CLEAR_WITH_WARNINGS
- BLOCKED

A release gate can consider:
- open critical findings;
- failed regression tests;
- missing transport dependencies;
- breaking API changes.

Do not automatically deploy to SAP; this is a validation gate unless a future explicit deployment integration is configured.
